package days;

public class V {
public static void main(String[] args) {
	System.out.println("hello");
}
	
}

