package days;



class De {
	int a=40;
	void display() {
		System.out.println("hello");
		
	}

}
