package days;

public class Pub1 {
public static void main(String[] args) {
Pub a1=new Pub();
System.out.println(a1.a);
System.out.println(a1.b);
}
}
