package days;

public class Pub {
	public int a=12;
	public int b=43;
	

}
