package days;

public class Pro {
	protected int a=34;
	protected int b=25;
	
		
	}


