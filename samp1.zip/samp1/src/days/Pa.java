package days;

public class Pa {
	private int a=30;
	public static void main(String[] args) {
		Pa a1=new Pa();
		System.out.println(a1.a);
	}
	

}
