package days;

public class A2 {
	int a=13;
	int b=34;
	static int c=45;
}



