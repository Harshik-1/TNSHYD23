package days;

public class A1 {
int a=12;
static int b=34;
public static void main(String[] args) {
	int g=45;
	System.out.println(g);
	A1 a1=new A1();
	System.out.println(a1.a);
	System.out.println(A1.b);
	
}
}
