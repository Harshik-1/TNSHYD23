/**
 * 
 */
/**
 * 
 */
module samp1 {
}