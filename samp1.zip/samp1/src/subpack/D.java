package subpack;
import pack.A.*;
import pack.A;

public class D {
	public static void main(String[] args) {
		A a1=new A();
	System.out.println(a1.a);
	}
	

}
