package pack;
import days.*;

public class Pro1 extends Pro {
	public static void main(String[] args) {
		Pro1 a1=new Pro1();
	System.out.println(a1.a);
	System.out.println(a1.b);
	}
	

}
