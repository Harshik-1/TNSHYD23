package pack;

public class A {
	int a=23;

}
