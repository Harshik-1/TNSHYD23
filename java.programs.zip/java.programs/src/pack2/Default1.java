package pack2;
import access_specifiers.*;

public class Default1 {
	public static void main(String[] args) {
		Default a1=new Default();
		System.out.println(a1.equals(a1));
		
	}

}
