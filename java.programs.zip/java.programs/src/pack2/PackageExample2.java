package pack2;

public class PackageExample2 {
	public void display() {
		System.out.println("bye pack");
	}

}
