package pack2;
import access_specifiers.*;

public class Protected1 extends Protected {

	public static void main(String[] args) {
     Protected1 a1=new Protected1();
     System.out.println(a1.a);
     a1.display();
     
	}

}
