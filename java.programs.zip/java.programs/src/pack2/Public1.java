package pack2;
import access_specifiers.*;

public class Public1 {
	public static void main(String[] args) {
		
	
Public a1=new Public();
  System.out.println(a1.a);
  
a1.display();
}

   
}
