package approachs;

public class Approachs2 {
	int a=45;
	String str="harshik";

}
