package approachs;

public class PackagesExamples {
	public void display() {
		System.out.println("hey pack");
	}

}
