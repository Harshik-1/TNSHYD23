package approachs;

public class Approach1 {
int a=67;
	public static void main(String[] args) {
	int b=34;
	String str="harshik";
Approach1 a1=new Approach1();
System.out.println(b);
System.out.println(a1.a);
System.out.println(str);
	}

}
