package approachs;

public class Approach22 {

public static void main(String[] args) {

   Approachs2 a1=new Approachs2();
System.out.println(a1.a);
System.out.println(a1.str);
}

}