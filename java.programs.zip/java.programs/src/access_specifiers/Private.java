package access_specifiers;

public class Private {
	private int a=34;
	private String str="Harshik";
	private void display() {
		System.out.println("wow");
	}

}
