package access_specifiers;

public class Public {
	public int a=34;
	public void display() {
		System.out.println("hello");
	}
	

}
