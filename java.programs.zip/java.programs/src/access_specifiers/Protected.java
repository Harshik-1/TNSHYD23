package access_specifiers;

public class Protected {
	protected int a=23;
	protected void display() {
		System.out.println("say! Hello");
	}
	

}
