package access_specifiers;

public class Default {
	void display() {
		System.out.println("hey u have default");
	}

}
