package access_specifiers;
import approachs.*;
import pack2.*;

public class PackageExample3 {
	public static void main(String[] args) {
		PackagesExamples a1=new PackagesExamples();
		PackageExample2 a2=new PackageExample2 ()	;
		a1.display();
		a2.display();
	}

}
