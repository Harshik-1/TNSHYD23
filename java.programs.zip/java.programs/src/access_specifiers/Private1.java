package access_specifiers;

public class Private1 {

	public static void main(String[] args) {
		Private a1=new Private();
		System.out.println(a1.a);
		System.out.println(a1.str);
        a1.display();
}

}
