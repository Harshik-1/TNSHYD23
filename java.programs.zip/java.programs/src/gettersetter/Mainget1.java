package gettersetter;

public class Mainget1 {
	public static void main(String[] args) {
		Get1 c1= new Get1();
		c1.speed=40;
		System.out.println(c1.speed);
	}

}




