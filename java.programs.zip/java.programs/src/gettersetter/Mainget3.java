package gettersetter;


public class Mainget3 {
	public static void main(String[] args) {
		Get3 car = new Get3 ();
		car.setSpeed (10);
		car.setDoors ("closed");
		car.setEngine ("on");
		car.setDriver("seated");
		//calling the function
		System.out.println (car.run ());
	}

}


